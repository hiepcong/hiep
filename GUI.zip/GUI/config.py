
HOST = "127.0.0.1"
PORT = 9000
TIMEOUT = 5       # seconds to wait for ACK
MAX_RETRY = 3
LOSS_RATE = 0.10  # simulated packet‑loss probability
STORAGE_DIR = "storage"
KEYS_DIR = "keys"